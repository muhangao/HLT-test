OK_FORMAT = True

test = {   'name': 'ngramlm-tri-perp-on-training',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def hid_test_trigram_perp_on_training():\n'
                                               '...     assert np.isclose(trigram_perp_on_training, 7.1182, atol=1e-4)\n'
                                               '>>> \n'
                                               '>>> hid_test_trigram_perp_on_training()\n',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
