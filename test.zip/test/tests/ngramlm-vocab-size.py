OK_FORMAT = True

test = {'name': 'ngramlm-vocab-size', 'points': 1, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
