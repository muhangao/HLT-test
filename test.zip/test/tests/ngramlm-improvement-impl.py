OK_FORMAT = True

test = {   'name': 'ngramlm-improvement-impl',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_handle_oov_improv_lm():\n'
                                               "...     assert 1 >= improved_trigramlm.word_prob(('~', '~'), 'f34qjf9qjf') > 0.\n"
                                               '...         \n'
                                               '>>> pub_test_handle_oov_improv_lm()\n',
                                       'failure_message': 'Please make sure you have handled OOV and word_prob() is within [0, 1].',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> def pub_test_improv_lm_context_type():\n'
                                               "...     assert isinstance(improved_trigramlm.contexts, dict), f'Expect `dict` got {type(improved_trigramlm.contexts)}'\n"
                                               '...         \n'
                                               '>>> pub_test_improv_lm_context_type()\n',
                                       'failure_message': 'improved_trigramlm.contexts type check failed.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '''>>> def pub_test_all_sum_to_1():
...     def _random_context():
...         corpus_id = random.randint(0, 1)
...         if corpus_id == 0:  # From training
...             sent = random.choice(corpus)
...         elif corpus_id == 1:  # From dev
...             sent = random.choice(dev_text)
...         else:
...             raise ValueError()
...         if len(sent) < improved_trigramlm.n:
...             return _random_context()
...         
...         ctx_start = random.randint(0, len(sent) - improved_trigramlm.n)
...         return tuple(sent[ctx_start:ctx_start + improved_trigramlm.n - 1])
...     
...     full_vocab = set(
...         sum((list(s) for s in corpus), [])
...         + sum((list(s) for s in dev_text), [])
...         + ['feaqwfeqjio',' zji129', 'v,1..', 'feq9018']
...         + ['~']
...     )    
...     model_vocab = set(improved_trigramlm.vocab)
...     non_model_vocab = full_vocab - model_vocab
...     for _ in range(500):
...         ctx = _random_context()
...         non_unk_prob = sum(improved_trigramlm.word_prob(ctx, w) for w in model_vocab)
...         unk_sample = random.sample(non_model_vocab, min(100, len(non_model_vocab)))
...         unk_prob = sum(improved_trigramlm.word_prob(ctx, w) for w in unk_sample) * len(non_model_vocab) / len(unk_sample)
...         total_prob = non_unk_prob + unk_prob
...         assert np.isclose(total_prob, 1.0, atol=5e-2) and total_prob < 1.05, f'Context={ctx}, NonUNKProb={non_unk_prob}, UNKProb={unk_prob}, Prob={total_prob}'
...         
>>> pub_test_all_sum_to_1()''',
                                       'failure_message': 'Each marginialized distribution should sum to 1 - any p > 1 would result in inf perplexity.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 3},
                                   {   'code': '>>> def _generate_ngrams(text: List[str], n: int) -> Counter:\n'
                                               '...     assert (isinstance(n, int) and n > 0)\n'
                                               '...     ngrams = Counter()\n'
                                               "...     extra = ['~' for _ in range(n - 1)]\n"
                                               '...     words = extra + text + extra\n'
                                               '...     ngram_tuples = zip(*[words[i:] for i in range(n)])\n'
                                               '...     for ng in ngram_tuples:\n'
                                               '...         ngrams[ng] += 1\n'
                                               '...     return ngrams\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> def _generate_ngrams_sentences(text: List[List[str]], n: int) -> Counter:\n'
                                               '...     """Generates n-grams for each sentence and aggregates them."""\n'
                                               '...     all_ngrams = Counter()\n'
                                               '...     for sentence in text:\n'
                                               '...         all_ngrams.update(_generate_ngrams(sentence, n))\n'
                                               '...     return all_ngrams\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> def _perplexity(model, data) -> float:\n'
                                               '...     ngrams: Counter = _generate_ngrams_sentences(data, model.n)\n'
                                               '...     prob_sum = 0.\n'
                                               '...     for ng, count in ngrams.items():\n'
                                               '...         cxt = ng[:-1]\n'
                                               '...         word_prob = model.word_prob(cxt, ng[-1])\n'
                                               '...         if word_prob == 0. or word_prob > 1.:\n'
                                               "...             return float('inf')\n"
                                               '...         else:\n'
                                               '...             prob_sum += math.log(word_prob) * count\n'
                                               '...     return math.exp(-prob_sum / float(sum(ngrams.values())))\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> def hid_test_improve_baseline(dev_test):\n'
                                               '...     baseline = _perplexity(trigramlm_laplace, dev_text[:500])\n'
                                               '...     improved = _perplexity(improved_trigramlm, dev_text[:500])\n'
                                               "...     assert improved < baseline, f'{improved} >= {baseline}'\n"
                                               '>>> \n'
                                               '>>> hid_test_improve_baseline(dev_text)\n',
                                       'failure_message': 'Did you actually improve from the baseline?',
                                       'hidden': True,
                                       'locked': False,
                                       'points': 5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
