OK_FORMAT = True

test = {   'name': 'cyk-impl',
    'points': 25,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_cyk_sanity_checkes_ret_type():\n'
                                               '...     parser = CYKParser(cnf_cfg_rules)\n'
                                               '...     parse_table = parser.parse("I shot an elephant in my pajamas".split())\n'
                                               '...     \n'
                                               "...     assert isinstance(parse_table, list), f'Expect List, but got {type(parse_table)}'\n"
                                               "...     assert isinstance(parse_table[0], list), f'Expect List, but got {type(parse_table)}'\n"
                                               "...     assert isinstance(parse_table[0][0], list), f'Expect List, but got {type(parse_table)}'\n"
                                               '...     \n'
                                               '>>> pub_test_cyk_sanity_checkes_ret_type()\n',
                                       'failure_message': 'CYK parser failed the return type check, please do not change the return type.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> def _verify_parse(root: Node, grammar: Dict[str, List[nltk.grammar.Production]]) -> bool:\n'
                                               '...     def _is_valid(s):\n'
                                               '...         is_valid = False\n'
                                               '...         for prods in grammar.values():\n'
                                               '...             for r in prods:\n'
                                               '...                 if not r.is_lexical():\n'
                                               '...                     continue\n'
                                               '...                 if r.rhs()[0] == s:\n'
                                               '...                     is_valid = True\n'
                                               '...                     break\n'
                                               '...         if is_valid:\n'
                                               '...             return True\n'
                                               '...         else:\n'
                                               '...             return False\n'
                                               '...     if isinstance(root.child1, str):\n'
                                               '...         return _is_valid(root.child1)\n'
                                               '...     elif root.child1 is not None or root.child2 is not None:\n'
                                               '...         if root.symbol not in grammar:\n'
                                               '...             return False\n'
                                               '...     else:\n'
                                               '...         return _is_valid(root.symbol)\n'
                                               '...     return _verify_parse(root.child1, grammar) if root.child1 is not None else True and _verify_parse(root.child2, grammar) if root.chile2 is not '
                                               'None else True\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> def grammar_mappings(g) -> Dict[str, List[nltk.grammar.Production]]:\n'
                                               '...     gmappings = {}\n'
                                               '...     for r in nltk.grammar.CFG.fromstring(g).productions():\n'
                                               '...         lhss = r.lhs().symbol()\n'
                                               '...         if lhss not in gmappings:\n'
                                               '...             gmappings[lhss] = []\n'
                                               '...         gmappings[lhss].append(r)\n'
                                               '...     return gmappings\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> def pub_test_cyk_eg1():\n'
                                               '...     parser = CYKParser(cnf_cfg_rules)\n'
                                               '...     \n'
                                               '...     # case 1\n'
                                               '...     parse_table = parser.parse("I shot an elephant in my pajamas".split())\n'
                                               '...     start_symbol = parser.grammar.start().symbol()\n'
                                               '...     final_nodes = [n for n in parse_table[-1][0] if n.symbol == start_symbol]\n'
                                               '...     for node in final_nodes:\n'
                                               '...         assert _verify_parse(node, grammar=grammar_mappings(cnf_cfg_rules))\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> pub_test_cyk_eg1()\n',
                                       'failure_message': 'Example test case failed for CYK - your parse does not follow the grammar.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5},
                                   {   'code': '>>> def pub_test_cyk_eg2():\n'
                                               '...     parser = CYKParser(cnf_cfg_rules)\n'
                                               '...     # case 2\n'
                                               '...     # Checks the final state\n'
                                               '...     parse_table2 = parser.parse("I shot an elephant on my pajamas".split())\n'
                                               '...     final_nodes2 = [n for n in parse_table2[-1][0] if n.symbol == start_symbol]\n'
                                               "...     assert len(final_nodes2) == 0, f'The text should not be able to be parsed.'\n"
                                               '...     # Checks the intermediate nodes\n'
                                               "...     assert len([z for x in parse_table2 for y in x for z in y]) > 6, f'The parse table still should have some intermediate nodes but "
                                               "{parse_table2}'\n"
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> pub_test_cyk_eg2()\n',
                                       'failure_message': 'Example test case failed for CYK - you parsed something that cannot be parsed.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
