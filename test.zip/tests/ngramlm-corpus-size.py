OK_FORMAT = True

test = {'name': 'ngramlm-corpus-size', 'points': 1, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
