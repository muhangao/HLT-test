OK_FORMAT = True

test = {   'name': 'ngramlm-empirical-distribution',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_emp_distr_sum_to_1():\n'
                                               "...     assert np.isclose(sum(compute_empirical_distribution(trigramlm, ('by', 'her'), 1000).values()), 1.)\n"
                                               "...     assert np.isclose(sum(compute_empirical_distribution(trigramlm, ('~', '~'), 1000).values()), 1.)\n"
                                               "...     assert np.isclose(sum(compute_empirical_distribution(trigramlm, ('hi', 'there'), 1000).values()), 1.)\n"
                                               '...     \n'
                                               '>>> pub_test_emp_distr_sum_to_1()\n',
                                       'failure_message': 'Empirical distribution does not sum to 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> def pub_test_emp_distr():\n'
                                               "...     ref_emp_distr = {'a': 0.099, 'orders': 0.013, 'had': 0.031, 'noticed': 0.016, 'to': 0.053, 'nobody': 0.017, 'time': 0.013, 'been': 0.107, "
                                               "'first': 0.022, 'done': 0.014, 'an': 0.01, 'tried': 0.011, 'no': 0.05, 'ten': 0.016, 'recognized': 0.024, 'brought': 0.014, 'not': 0.013, 'deserved': "
                                               "0.013, 'the': 0.03, 'heard': 0.015, 'built': 0.015, 'lived': 0.016, 'each': 0.017, 'still': 0.011, 'abandoned': 0.01, 'gained': 0.033, 'quite': 0.013, "
                                               "'sent': 0.011, 'only': 0.021, 'found': 0.01, 'agreed': 0.018, 'got': 0.014, 'command': 0.012, 'three': 0.014, 'forgotten': 0.01, 'worn': 0.009, "
                                               "'lost': 0.012, 'engaged': 0.01, 'paid': 0.017, 'of': 0.01, 'trusted': 0.013, 'withdrawn': 0.016, 'altered': 0.014, 'thrown': 0.02, 'landed': 0.014, "
                                               "'other': 0.012, 'fully': 0.009, 'played': 0.005, 'admitted': 0.011, 'grain': 0.008, 'everything': 0.006, 'once': 0.008}\n"
                                               "...     sys_emp_distr = compute_empirical_distribution(trigramlm, ('we', 'have'), 10000)\n"
                                               '...     for word, prob in ref_emp_distr.items():\n'
                                               "...         assert np.isclose(sys_emp_distr[word], prob, atol=2e-2), f'emp_prob={sys_emp_distr[word]}, prob={prob}'\n"
                                               '...     \n'
                                               '>>> pub_test_emp_distr()\n',
                                       'failure_message': 'Empirical distribution does not match the reference.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
